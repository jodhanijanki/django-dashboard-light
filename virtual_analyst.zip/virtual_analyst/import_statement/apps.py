from django.apps import AppConfig


class ImportStatementConfig(AppConfig):
    name = 'import_statement'
