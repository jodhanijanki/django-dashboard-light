from django.apps import AppConfig


class AnalyseStatementConfig(AppConfig):
    name = 'analyse_statement'
